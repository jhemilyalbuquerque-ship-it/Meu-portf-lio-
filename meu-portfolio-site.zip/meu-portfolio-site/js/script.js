// Portfólio Jhemily Albuquerque
// Pequenos aprimoramentos de interface (recurso opcional, não obrigatório).

document.addEventListener('DOMContentLoaded', function () {

  // Menu mobile
  var navToggle = document.getElementById('navToggle');
  var siteNav = document.getElementById('siteNav');

  if (navToggle && siteNav) {
    navToggle.addEventListener('click', function () {
      var isOpen = siteNav.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });

    // Fecha o menu ao clicar em um link (útil no mobile)
    siteNav.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        siteNav.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  // Ano atual no rodapé
  var yearEl = document.getElementById('year');
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }

  // Formulário de contato (demonstração local, sem backend)
  var form = document.getElementById('contactForm');
  var status = document.getElementById('formStatus');

  if (form && status) {
    form.addEventListener('submit', function (event) {
      event.preventDefault();

      if (!form.checkValidity()) {
        status.textContent = 'Preencha todos os campos antes de enviar.';
        return;
      }

      var nome = document.getElementById('nome').value.trim();
      status.textContent = 'Obrigada, ' + nome + '! Sua mensagem foi registrada (formulário de demonstração).';
      form.reset();
    });
  }

});
