# Portfólio Pessoal — Jhemily Albuquerque

Site pessoal em formato de portfólio profissional, desenvolvido como Atividade
Prática III da disciplina de Desenvolvimento Front-End (Engenharia de Software,
FAMETRO — 5º período, noturno).

## Objetivo

Aplicar HTML5 semântico, CSS3, Flexbox/Grid e responsividade na construção de
uma página funcional, organizada e visualmente coerente para apresentação de
informações profissionais e acadêmicas.

## Estrutura do projeto

```
meu-portfolio-site/
│
├── index.html
├── css/
│   └── style.css
├── js/
│   └── script.js        (opcional: menu mobile, ano no rodapé, feedback do formulário)
├── img/                  (reservado para imagens adicionais)
└── README.md
```

## Conceito de design

O visual segue a ideia de "estrutura visível": pequenas anotações no estilo
`<tag>` marcam cada seção, remetendo diretamente ao HTML semântico usado por
baixo — header, main, section e footer. A paleta usa papel neutro, tinta azul-
marinho e um destaque em âmbar, com Space Grotesk para títulos e IBM Plex Sans
para texto corrido.

## Seções

- **Header** — logo/nome e menu de navegação organizado com Flexbox.
- **Sobre mim** — apresentação, avatar ilustrado em SVG e informações acadêmicas.
- **Habilidades** — cards organizados em grid com as tecnologias estudadas.
- **Projetos** — lista de projetos (incluindo este próprio portfólio).
- **Contato** — e-mail, GitHub, LinkedIn e formulário de contato local.
- **Footer** — copyright, ano atual e identificação do projeto.

## Como visualizar

1. Abra a pasta no VS Code.
2. Use a extensão **Live Server** e clique em "Go Live", ou abra `index.html`
   diretamente no navegador.

## Personalização

- Substitua o e-mail, o link do GitHub e do LinkedIn em `index.html` (seção
  `#contato`) pelos seus dados reais.
- Adicione fotos ou imagens próprias na pasta `img/` e referencie-as no HTML,
  caso queira substituir o avatar ilustrado.
- O formulário de contato é uma demonstração front-end (sem envio real) —
  pode ser conectado a um serviço como Formspree ou EmailJS se desejado.

## Publicação sugerida

- **GitHub Pages** ou **Netlify** para publicar o site e obter um link público.
- Repositório no GitHub com o código-fonte completo.

## Tecnologias

- HTML5 semântico
- CSS3 (variáveis, Flexbox, Grid, media queries)
- JavaScript (progressivo, opcional)
